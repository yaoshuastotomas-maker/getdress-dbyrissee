/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b1bafff1'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "splash-screen.png",
    "revision": "93a97ac3f26ab4d8dd50cdff8b57e7a5"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "d1b8e50588581b2bafaa6df5b3d7b1ee"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4a6fd9d42baeb3494de1820fa6d0779f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "099c80ce9037e774c7535e9908c34a75"
  }, {
    "url": "index.html",
    "revision": "427970e5bafc7eb56e9c8409358facbd"
  }, {
    "url": "favicon.png",
    "revision": "bd3eae21bdb1d2646601e5c6e52b9a04"
  }, {
    "url": "favicon.ico",
    "revision": "51fdaca8134d61f2e11d3ee2551056c1"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "4ed7320c992b4697ce1d7d447b124774"
  }, {
    "url": "apple-touch-icon-1024x1024.png",
    "revision": "0d1b5da1a1b1b9d0e393d68a7cd19211"
  }, {
    "url": "assets/index-D2WWvsvB.js",
    "revision": null
  }, {
    "url": "assets/index-2y_OIu6y.css",
    "revision": null
  }, {
    "url": "apple-touch-icon-1024x1024.png",
    "revision": "0d1b5da1a1b1b9d0e393d68a7cd19211"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "4ed7320c992b4697ce1d7d447b124774"
  }, {
    "url": "favicon.ico",
    "revision": "51fdaca8134d61f2e11d3ee2551056c1"
  }, {
    "url": "favicon.png",
    "revision": "bd3eae21bdb1d2646601e5c6e52b9a04"
  }, {
    "url": "pwa-192x192.png",
    "revision": "099c80ce9037e774c7535e9908c34a75"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4a6fd9d42baeb3494de1820fa6d0779f"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "d1b8e50588581b2bafaa6df5b3d7b1ee"
  }, {
    "url": "robots.txt",
    "revision": "2ec9c5e753d1b672bc25648608c758f8"
  }, {
    "url": "sitemap.xml",
    "revision": "d2a618d0f50b85725a998f6de6b032a4"
  }, {
    "url": "splash-screen.png",
    "revision": "93a97ac3f26ab4d8dd50cdff8b57e7a5"
  }, {
    "url": "manifest.webmanifest",
    "revision": "f146e6b1f8f0dcc498922383471e4f5d"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-stylesheets",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-webfonts",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/images\.unsplash\.com\/.*/i, new workbox.StaleWhileRevalidate({
    "cacheName": "unsplash-images",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
